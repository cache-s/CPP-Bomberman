============================================ ARC-170 fighter Ship - Vaisseau de combat ARC-170 =======================================================

[En]

Hi and thank you for downloading this model from Jetstorm_477 !

> Model in 6 formats : .obj (2 Versions) ; .max ; .fbx ; .dxf ; .3ds ; .stl
  3DS Max model (.max) is the original file (Submitted by : "ysup12") that I exported to the above formats.
    Info - .3ds model includes neither color nor texture, and I don't guarantee the success of .stl and .dxf models importation ...
  However, .obj, .fbx and .max models were tested in 3ds max (and work!).
  - 2 versions of .obj model ; if one doesn't work, try the other !
  In addition, the "[.obj] (Sh3d adapted)" model is suitable for import into the free Sweet Home 3D software.
  - I recommend you to remove the models from any archive during using, in order to avoid import problems.

  � Model submitted on www.tf3dm.com by "ysup12" in June 2012, to this page : http://tf3dm.com/3d-model/arc-170-23714.html
In case of copyright problems, contact him.

  Don't forget to leave me a comment on the site, or an e-mail in case of problems or suggestions !
My e-mail adress : ley1998@live.fr

	enjoy ;)

******************************************************************************************************************************************************
[Fr]

Boujour et merci d'avoir t�l�charg� ce mod�le de Jetstorm_477 !

> Mod�le en 6 formats : .obj (2 Versions) ; .max ; .fbx ; .dxf ; .3ds ; .stl
  Le mod�le 3DS Max (.max) est le fichier original (mis en ligne par "ysup12") que j'ai export� aux formats ci-dessus.
    Info - Le mod�le .3ds ne comporte ni couleurs, ni textures, et je ne garantis pas la r�ussite de l'importation des mod�les .stl et .dxf...
  Cependant, les mod�les .obj, .fbx et .max ont �t� test�s dans 3ds max (et fonctionnent !).
  - 2 versions du mod�le .obj ; si l'une ne fonctionne pas, essayer l'autre !
  De plus, le mod�le "[.obj] (Sh3d adapted)" est adapt� pour l'importation dans le logiciel gratuit Sweet Home 3D.
  - Je vous recommande d'extraire les mod�les de toute archive lors de leur utilisation pour �viter les probl�mes d'import.

  � Mod�le mis en ligne sur www.tf3dm.com par "ysup12" en juin 2012, � cette page : http://tf3dm.com/3d-model/arc-170-23714.html
Pour les droits d'auteur, le contacter.

  N'h�sitez pas � me laisser un commentaire sur le site, ou un mail en cas de probl�mes ou suggestions !
Mon mail : ley1998@live.fr

	�+ ;)

=======================================================================================================================================================